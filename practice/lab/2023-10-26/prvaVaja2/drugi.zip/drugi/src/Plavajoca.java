public class Plavajoca {
        public static void main(String args[]){
            float ff = 1.1f;
            double ff1 = 2.0;
            System.out.println(ff * ff1);
            boolean jaNe = false;
            if(jaNe) {
                System.out.println("JA");
            }else{
                System.out.println("NE");
            }

    }
}
// ne mešat float and double, ker dobiš napako pri natančnosti konverziji
