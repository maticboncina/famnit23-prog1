import com.sun.jdi.request.StepRequest;

public class Plavajoca {
        public static void main(String args[]){
            float ff = 1.1f;
            double ff1 = 2.0;
            System.out.println(ff * ff1);
            boolean jaNe = false;
            if(jaNe) {
                System.out.println("JA");
            }else{
                System.out.println("NE");
            }
            String nekeBesede = "Danes je lepo vreme";
            System.out.println(nekeBesede + nekeBesede);
            System.out.println(nekeBesede.length());
            System.out.println(nekeBesede.charAt(0));
            System.out.println(nekeBesede.charAt(nekeBesede.length() - 1));

    }
}
// ne mešat float and double, ker dobiš napako pri natančnosti konverziji
