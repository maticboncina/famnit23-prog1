// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println("neki napišite");
        long stevilo;
        stevilo = 2000000000;
        long novoStevilo = 2000000000;
        long rezultat = stevilo + novoStevilo;
        System.out.println(stevilo);
        System.out.println(rezultat);
        System.out.println("To je rezultat: " + " res je: " + (stevilo + novoStevilo));

    }
}

